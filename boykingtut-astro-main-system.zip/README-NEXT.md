# BoyKingTut.com — Astro/Cloudflare Phase 1

This package is designed to drop into the existing `astro-blog-starter-template` repository.

## What Phase 1 includes

- Responsive desktop + mobile homepage
- 18+ access / crypto-risk gate
- Affiliate / Make Money popup
- Crypto, local advertising, affiliate, Solana, Reddit, TikTok, Second Life / Metaverse, Egypt, FAQ and pricing sections
- Solo Leverage Alarm pricing/requirements
- Server-side Discord helper stub
- Cloudflare `.assetsignore`
- Environment-variable example

## What is intentionally NOT live yet

- Google Login / Signup
- Owner/Admin dashboard
- Customer/Affiliate database
- Solana checkout creation
- CoinGecko live quote
- 5-minute checkout timer
- On-chain Solana payment verification
- Discord signup/order event route
- Affiliate SOL payouts
- Business brochure upload/storage

Those require the backend bindings/secrets/database to be configured first.

## Install into the existing repo

Copy these folders/files into the root of your GitHub Astro repository:

- `src/`
- `public/.assetsignore`
- `.dev.vars.example`

Do NOT replace `package.json`, `astro.config.mjs`, or `wrangler.jsonc` yet unless we first inspect your current versions.

## Cloudflare requirement for dynamic Phase 2

Your project will need the Cloudflare Astro adapter and server rendering.

If the adapter is not already configured, from the project directory run:

```bash
npx astro add cloudflare
```

Cloudflare's current Workers/Astro setup uses a generated Worker entry in `dist/_worker.js/index.js`,
an `ASSETS` binding, and `nodejs_compat`.

## Important security

The Discord webhook previously pasted in chat should be regenerated before launch.

Store the new webhook directly in Cloudflare as a Secret named:

`DISCORD_SIGNUP_WEBHOOK`

Never put it in `index.astro`, GitHub, `.dev.vars.example`, client JavaScript, or a public environment variable.

## After Phase 1 is deployed

Next phase:

1. Google OAuth
2. D1 database
3. account roles (customer, affiliate, crypto member, admin, owner)
4. Discord event notifications
5. CoinGecko SOL/USD quote
6. 5-minute locked checkout
7. Solana RPC verification
8. affiliate/customer dashboards
9. admin dashboard
10. upload/storage for business brochures

## Second Life / Metaverse

Public destination:

`https://maps.secondlife.com/secondlife/Wild%20Hollow/91/153/2451`

Mobile information:

`https://go.secondlife.com/mobile`
